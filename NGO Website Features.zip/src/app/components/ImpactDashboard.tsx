import { useEffect, useRef, useState } from "react";
import { motion, useInView } from "motion/react";
import { Users, TreePine, UserCheck, MapPin } from "lucide-react";

function useCountUp(target: number, duration = 2000, start = false) {
  const [count, setCount] = useState(0);
  useEffect(() => {
    if (!start) return;
    let startTime: number | null = null;
    const step = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = Math.min((timestamp - startTime) / duration, 1);
      const ease = 1 - Math.pow(1 - progress, 3);
      setCount(Math.floor(ease * target));
      if (progress < 1) requestAnimationFrame(step);
    };
    requestAnimationFrame(step);
  }, [start, target, duration]);
  return count;
}

const stats = [
  {
    icon: Users,
    value: 50000,
    suffix: "+",
    label: "Lives Impacted",
    color: "bg-green-50 text-green-600",
    iconBg: "bg-green-100",
  },
  {
    icon: TreePine,
    value: 25000,
    suffix: "+",
    label: "Trees Planted",
    color: "bg-emerald-50 text-emerald-600",
    iconBg: "bg-emerald-100",
  },
  {
    icon: UserCheck,
    value: 900,
    suffix: "+",
    label: "Women Empowered",
    color: "bg-orange-50 text-orange-600",
    iconBg: "bg-orange-100",
  },
  {
    icon: MapPin,
    value: 28,
    suffix: " States",
    label: "Nationwide Reach",
    color: "bg-amber-50 text-amber-600",
    iconBg: "bg-amber-100",
  },
];

function StatCard({ stat, index, animate }: { stat: typeof stats[0]; index: number; animate: boolean }) {
  const count = useCountUp(stat.value, 2000 + index * 200, animate);
  const Icon = stat.icon;
  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      animate={animate ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.6, delay: index * 0.12 }}
      className={`rounded-2xl p-6 ${stat.color} border border-white shadow-sm hover:shadow-md transition-shadow flex flex-col items-center text-center`}
    >
      <div className={`w-14 h-14 rounded-full ${stat.iconBg} flex items-center justify-center mb-4`}>
        <Icon className="w-7 h-7" />
      </div>
      <div className="text-4xl font-extrabold mb-1">
        {count.toLocaleString("en-IN")}{stat.suffix}
      </div>
      <div className="text-sm font-semibold opacity-80 uppercase tracking-wide">{stat.label}</div>
    </motion.div>
  );
}

export function ImpactDashboard() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="impact" className="py-20 bg-white" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <span className="text-orange-500 font-semibold uppercase tracking-widest text-sm">Our Impact</span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-gray-900 mt-2">
            Numbers That Speak Louder
          </h2>
          <p className="text-gray-500 mt-3 max-w-xl mx-auto">
            Every number represents a real story, a changed life, a brighter future.
          </p>
        </motion.div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-5">
          {stats.map((stat, i) => (
            <StatCard key={stat.label} stat={stat} index={i} animate={inView} />
          ))}
        </div>
      </div>
    </section>
  );
}
