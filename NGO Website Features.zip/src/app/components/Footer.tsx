import { Heart, Mail, Phone, MapPin, Facebook, Twitter, Instagram, Youtube, ArrowRight } from "lucide-react";

const footerLinks = {
  "Quick Links": ["Home", "About Us", "Our Programs", "Success Stories", "Blog"],
  "Get Involved": ["Donate", "Volunteer", "Corporate CSR", "Fundraise", "Spread the Word"],
  "Programs": ["Education", "Healthcare", "Women Empowerment", "Environment", "Disaster Relief"],
};

const socialLinks = [
  { Icon: Facebook, label: "Facebook", color: "hover:bg-blue-600" },
  { Icon: Twitter, label: "Twitter", color: "hover:bg-sky-500" },
  { Icon: Instagram, label: "Instagram", color: "hover:bg-pink-600" },
  { Icon: Youtube, label: "YouTube", color: "hover:bg-red-600" },
];

export function Footer() {
  return (
    <footer id="contact" className="bg-gray-900 text-gray-300">
      {/* CTA Banner */}
      <div className="bg-gradient-to-r from-green-600 to-green-700 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-6">
          <div>
            <h3 className="text-2xl font-extrabold text-white">Ready to Make a Difference?</h3>
            <p className="text-green-100 mt-1">Join 50,000+ people who've already changed lives.</p>
          </div>
          <div className="flex gap-3 flex-shrink-0">
            <a href="#donate" className="bg-orange-500 hover:bg-orange-600 text-white px-6 py-3 rounded-full font-bold transition-colors flex items-center gap-2">
              Donate Now <ArrowRight className="w-4 h-4" />
            </a>
            <a href="#about" className="bg-white/15 hover:bg-white/25 border border-white/40 text-white px-6 py-3 rounded-full font-bold transition-colors">
              Volunteer
            </a>
          </div>
        </div>
      </div>

      {/* Main footer */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid lg:grid-cols-5 gap-10">
          {/* Brand */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-9 h-9 rounded-full bg-green-600 flex items-center justify-center">
                <Heart className="w-5 h-5 text-white fill-white" />
              </div>
              <span className="text-xl font-bold text-white">
                Inamigos<span className="text-orange-400">Foundation</span>
              </span>
            </div>
            <p className="text-sm text-gray-400 leading-relaxed mb-6 max-w-xs">
              A registered non-profit organisation working to uplift underprivileged communities
              across India since 2005. FCRA certified. 80G tax exemption available.
            </p>

            {/* Contact */}
            <div className="space-y-2 text-sm">
              <div className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors">
                <Mail className="w-4 h-4 text-green-500" />
                <span>contact@inamigosfoundation.org</span>
              </div>
              <div className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors">
                <Phone className="w-4 h-4 text-green-500" />
                <span>+91 98765 43210</span>
              </div>
              <div className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors">
                <MapPin className="w-4 h-4 text-green-500" />
                <span>New Delhi, India — 110001</span>
              </div>
            </div>

            {/* Social */}
            <div className="flex gap-3 mt-6">
              {socialLinks.map(({ Icon, label, color }) => (
                <button
                  key={label}
                  aria-label={label}
                  className={`w-9 h-9 rounded-full bg-gray-700 ${color} flex items-center justify-center transition-colors`}
                >
                  <Icon className="w-4 h-4 text-white" />
                </button>
              ))}
            </div>
          </div>

          {/* Links */}
          {Object.entries(footerLinks).map(([section, links]) => (
            <div key={section}>
              <h4 className="text-white font-bold mb-4 text-sm uppercase tracking-wider">{section}</h4>
              <ul className="space-y-2">
                {links.map((link) => (
                  <li key={link}>
                    <a href="#" className="text-sm text-gray-400 hover:text-orange-400 transition-colors flex items-center gap-1 group">
                      <span className="group-hover:translate-x-1 transition-transform">{link}</span>
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Newsletter */}
        <div className="mt-12 p-6 bg-gray-800 rounded-2xl">
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
            <div className="flex-1">
              <p className="text-white font-bold">Subscribe to our newsletter</p>
              <p className="text-gray-400 text-sm">Get impact stories, campaign updates, and more.</p>
            </div>
            <div className="flex gap-2 w-full sm:w-auto">
              <input
                type="email"
                placeholder="your@email.com"
                className="flex-1 sm:w-56 bg-gray-700 text-white placeholder-gray-500 px-4 py-2.5 rounded-full text-sm outline-none border border-gray-600 focus:border-green-500 transition-colors"
              />
              <button className="bg-green-600 hover:bg-green-700 text-white px-5 py-2.5 rounded-full text-sm font-semibold transition-colors flex-shrink-0">
                Subscribe
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-gray-800 py-5">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-3 text-sm text-gray-500">
          <p>© 2026 Inamigos Foundation. All rights reserved. Registered NGO under Societies Act.</p>
          <div className="flex gap-5">
            <a href="#" className="hover:text-white transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-white transition-colors">Terms of Use</a>
            <a href="#" className="hover:text-white transition-colors">80G Certificate</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
