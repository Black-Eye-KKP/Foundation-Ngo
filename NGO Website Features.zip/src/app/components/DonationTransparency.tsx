import { useRef } from "react";
import { motion, useInView } from "motion/react";
import { FileText, Shield } from "lucide-react";

const breakdown = [
  { label: "Education", percent: 60, color: "bg-green-500", light: "bg-green-100", textColor: "text-green-700" },
  { label: "Food & Nutrition", percent: 20, color: "bg-orange-500", light: "bg-orange-100", textColor: "text-orange-700" },
  { label: "Medical Aid", percent: 10, color: "bg-blue-500", light: "bg-blue-100", textColor: "text-blue-700" },
  { label: "Administration", percent: 10, color: "bg-gray-400", light: "bg-gray-100", textColor: "text-gray-600" },
];

function ProgressBar({ item, animate, index }: { item: typeof breakdown[0]; animate: boolean; index: number }) {
  return (
    <div className="mb-5">
      <div className="flex justify-between items-center mb-2">
        <div className="flex items-center gap-2">
          <span className={`w-3 h-3 rounded-full ${item.color}`} />
          <span className="font-semibold text-gray-700">{item.label}</span>
        </div>
        <span className={`font-bold ${item.textColor}`}>{item.percent}%</span>
      </div>
      <div className={`h-4 rounded-full ${item.light} overflow-hidden`}>
        <motion.div
          initial={{ width: 0 }}
          animate={animate ? { width: `${item.percent}%` } : { width: 0 }}
          transition={{ duration: 1, delay: index * 0.15, ease: "easeOut" }}
          className={`h-full rounded-full ${item.color}`}
        />
      </div>
    </div>
  );
}

export function DonationTransparency() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section id="donate" className="py-20 bg-gradient-to-br from-green-50 to-emerald-50" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <span className="text-orange-500 font-semibold uppercase tracking-widest text-sm">Transparency</span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-gray-900 mt-2">
            How Your Donation Helps
          </h2>
          <p className="text-gray-500 mt-3 max-w-xl mx-auto">
            Every ₹100 you donate is allocated with complete transparency and accountability.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Bar chart */}
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7 }}
            className="bg-white rounded-2xl p-8 shadow-sm border border-green-100"
          >
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-full bg-green-100 flex items-center justify-center">
                <Shield className="w-5 h-5 text-green-600" />
              </div>
              <div>
                <p className="text-xs text-gray-500 uppercase tracking-wide">For every</p>
                <p className="font-extrabold text-2xl text-green-700">₹100 Donated</p>
              </div>
            </div>
            {breakdown.map((item, i) => (
              <ProgressBar key={item.label} item={item} animate={inView} index={i} />
            ))}
          </motion.div>

          {/* Info cards */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="space-y-5"
          >
            {breakdown.map((item) => (
              <div
                key={item.label}
                className={`flex items-center gap-4 p-4 rounded-xl ${item.light} border border-white`}
              >
                <div className={`w-12 h-12 rounded-full ${item.color} flex items-center justify-center text-white font-extrabold text-lg`}>
                  ₹{item.percent}
                </div>
                <div>
                  <p className={`font-bold ${item.textColor}`}>{item.label}</p>
                  <p className="text-sm text-gray-500">
                    {item.percent}% of your donation supports this cause
                  </p>
                </div>
              </div>
            ))}

            <a
              href="#"
              className="mt-4 flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-6 py-3 rounded-full font-semibold w-fit transition-colors"
            >
              <FileText className="w-4 h-4" />
              View Annual Report
            </a>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
