import { useRef } from "react";
import { motion, useInView } from "motion/react";
import { ArrowRight, Quote } from "lucide-react";

const stories = [
  {
    id: 1,
    name: "Rita Sharma",
    location: "Rajasthan",
    title: "From Dropout to Graduate",
    story:
      "Rita completed her education through our scholarship program. Today she is a schoolteacher, inspiring hundreds of girls in her village to dream bigger.",
    image:
      "https://images.unsplash.com/photo-1524069290683-0457abfe42c3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=600",
    tag: "Education",
    tagColor: "bg-green-100 text-green-700",
  },
  {
    id: 2,
    name: "Priya Devi",
    location: "Bihar",
    title: "Empowered Through Skill Training",
    story:
      "After joining our women's empowerment workshop, Priya started her own tailoring business. She now employs 5 other women from her community.",
    image:
      "https://images.unsplash.com/photo-1522661067900-ab829854a57f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=600",
    tag: "Empowerment",
    tagColor: "bg-orange-100 text-orange-700",
  },
  {
    id: 3,
    name: "Arjun Kumar",
    location: "Madhya Pradesh",
    title: "Health Camp Changed My Life",
    story:
      "Arjun received timely medical treatment through our rural health camp. A simple eye surgery restored his vision and allowed him to return to farming.",
    image:
      "https://images.unsplash.com/photo-1628717341663-0007b0ee2597?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=600",
    tag: "Healthcare",
    tagColor: "bg-blue-100 text-blue-700",
  },
];

export function SuccessStories() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section id="about" className="py-20 bg-white" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <span className="text-orange-500 font-semibold uppercase tracking-widest text-sm">Success Stories</span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-gray-900 mt-2">
            Lives We've Transformed
          </h2>
          <p className="text-gray-500 mt-3 max-w-xl mx-auto">
            Behind every statistic is a real person with a real story of hope, courage, and change.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-7">
          {stories.map((story, i) => (
            <motion.div
              key={story.id}
              initial={{ opacity: 0, y: 40 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: i * 0.13 }}
              className="group rounded-2xl overflow-hidden shadow-sm hover:shadow-lg transition-shadow border border-gray-100 flex flex-col"
            >
              <div className="relative overflow-hidden h-52">
                <img
                  src={story.image}
                  alt={story.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-3 left-3">
                  <span className={`px-3 py-1 rounded-full text-xs font-bold ${story.tagColor}`}>
                    {story.tag}
                  </span>
                </div>
              </div>

              <div className="p-6 flex flex-col flex-1">
                <div className="w-8 h-8 rounded-full bg-orange-100 flex items-center justify-center mb-3">
                  <Quote className="w-4 h-4 text-orange-500" />
                </div>
                <h3 className="font-bold text-lg text-gray-900 mb-1">{story.title}</h3>
                <p className="text-sm text-gray-500 mb-1 font-medium">
                  {story.name} · {story.location}
                </p>
                <p className="text-gray-600 text-sm leading-relaxed flex-1 mt-2">{story.story}</p>
                <button className="mt-5 flex items-center gap-2 text-green-600 hover:text-green-700 font-semibold text-sm transition-colors group/btn">
                  Read Full Story
                  <ArrowRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
                </button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
