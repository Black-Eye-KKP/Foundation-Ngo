import { useRef, useState } from "react";
import { motion, useInView } from "motion/react";
import { Heart, Target, Users, Clock } from "lucide-react";

const campaigns = [
  {
    id: 1,
    title: "Feed 100 Children Daily",
    description:
      "Provide nutritious mid-day meals to 100 underprivileged children in government schools across rural Bihar.",
    goal: 100000,
    raised: 80000,
    image:
      "https://images.unsplash.com/photo-1524069290683-0457abfe42c3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=600",
    tag: "Food & Nutrition",
    tagColor: "bg-orange-100 text-orange-700",
    barColor: "bg-orange-500",
    donors: 234,
    daysLeft: 18,
  },
  {
    id: 2,
    title: "Plant 1000 Trees",
    description:
      "Restore forest cover and combat climate change by planting native trees in degraded lands of Madhya Pradesh.",
    goal: 50000,
    raised: 25000,
    image:
      "https://images.unsplash.com/photo-1622383563227-04401ab4e5ea?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=600",
    tag: "Environment",
    tagColor: "bg-green-100 text-green-700",
    barColor: "bg-green-500",
    donors: 156,
    daysLeft: 30,
  },
  {
    id: 3,
    title: "Girls' Education Fund",
    description:
      "Provide scholarships, books, and uniforms to 50 girls from rural families to complete their secondary education.",
    goal: 75000,
    raised: 60000,
    image:
      "https://images.unsplash.com/flagged/photo-1574097656146-0b43b7660cb6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&w=600",
    tag: "Education",
    tagColor: "bg-blue-100 text-blue-700",
    barColor: "bg-blue-500",
    donors: 312,
    daysLeft: 12,
  },
];

function formatINR(amount: number) {
  return "₹" + amount.toLocaleString("en-IN");
}

function CampaignCard({ campaign, index, animate }: { campaign: typeof campaigns[0]; index: number; animate: boolean }) {
  const [liked, setLiked] = useState(false);
  const percent = Math.round((campaign.raised / campaign.goal) * 100);

  return (
    <motion.div
      initial={{ opacity: 0, y: 40 }}
      animate={animate ? { opacity: 1, y: 0 } : {}}
      transition={{ duration: 0.6, delay: index * 0.13 }}
      className="group rounded-2xl overflow-hidden shadow-sm hover:shadow-xl transition-shadow border border-gray-100 bg-white flex flex-col"
    >
      <div className="relative overflow-hidden h-52">
        <img
          src={campaign.image}
          alt={campaign.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute top-3 left-3">
          <span className={`px-3 py-1 rounded-full text-xs font-bold ${campaign.tagColor}`}>
            {campaign.tag}
          </span>
        </div>
        <button
          onClick={() => setLiked((l) => !l)}
          className="absolute top-3 right-3 w-8 h-8 rounded-full bg-white/90 flex items-center justify-center shadow hover:scale-110 transition-transform"
        >
          <Heart
            className={`w-4 h-4 transition-colors ${liked ? "fill-red-500 text-red-500" : "text-gray-400"}`}
          />
        </button>
      </div>

      <div className="p-6 flex flex-col flex-1">
        <h3 className="font-extrabold text-gray-900 text-lg mb-2 leading-tight">{campaign.title}</h3>
        <p className="text-gray-500 text-sm leading-relaxed mb-5 flex-1">{campaign.description}</p>

        {/* Progress */}
        <div className="mb-4">
          <div className="flex justify-between text-sm mb-1.5">
            <span className="font-bold text-gray-800">Raised: {formatINR(campaign.raised)}</span>
            <span className="font-bold text-gray-500">{percent}%</span>
          </div>
          <div className="h-3 bg-gray-100 rounded-full overflow-hidden">
            <motion.div
              initial={{ width: 0 }}
              animate={animate ? { width: `${percent}%` } : { width: 0 }}
              transition={{ duration: 1.2, delay: index * 0.13 + 0.4, ease: "easeOut" }}
              className={`h-full rounded-full ${campaign.barColor}`}
            />
          </div>
          <div className="flex justify-between mt-1.5">
            <span className="text-xs text-gray-400">Goal: {formatINR(campaign.goal)}</span>
          </div>
        </div>

        {/* Meta */}
        <div className="flex items-center gap-4 text-xs text-gray-500 mb-5">
          <span className="flex items-center gap-1">
            <Users className="w-3.5 h-3.5" />
            {campaign.donors} donors
          </span>
          <span className="flex items-center gap-1">
            <Clock className="w-3.5 h-3.5" />
            {campaign.daysLeft} days left
          </span>
          <span className="flex items-center gap-1">
            <Target className="w-3.5 h-3.5" />
            {percent}% funded
          </span>
        </div>

        <button className="w-full bg-green-600 hover:bg-green-700 text-white py-3 rounded-full font-bold transition-colors flex items-center justify-center gap-2">
          <Heart className="w-4 h-4" />
          Donate Now
        </button>
      </div>
    </motion.div>
  );
}

export function CampaignCards() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });

  return (
    <section className="py-20 bg-gray-50" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-12"
        >
          <span className="text-orange-500 font-semibold uppercase tracking-widest text-sm">Active Campaigns</span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-gray-900 mt-2">
            Support a Cause Today
          </h2>
          <p className="text-gray-500 mt-3 max-w-xl mx-auto">
            Choose a campaign that resonates with you and make a direct, measurable impact.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-7">
          {campaigns.map((c, i) => (
            <CampaignCard key={c.id} campaign={c} index={i} animate={inView} />
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={inView ? { opacity: 1 } : {}}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="text-center mt-10"
        >
          <button className="border-2 border-green-600 text-green-700 hover:bg-green-600 hover:text-white px-8 py-3 rounded-full font-bold transition-all">
            View All Campaigns
          </button>
        </motion.div>
      </div>
    </section>
  );
}
