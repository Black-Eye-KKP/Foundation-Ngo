import { useRef, useState } from "react";
import { motion, useInView, AnimatePresence } from "motion/react";
import { Star, ChevronLeft, ChevronRight, Quote } from "lucide-react";

const testimonials = [
  {
    id: 1,
    name: "Rahul Mehta",
    role: "Regular Donor",
    location: "Mumbai",
    rating: 5,
    text: "Wonderful NGO. Highly trusted. I've been donating for 3 years and the transparency in fund usage is commendable. You can actually see your contribution making a difference.",
    avatar: "RM",
    avatarColor: "bg-green-500",
  },
  {
    id: 2,
    name: "Sunita Rao",
    role: "Volunteer",
    location: "Bangalore",
    rating: 5,
    text: "Volunteering here changed my life. The team's dedication is inspiring. I spent a month teaching in a rural school through their program and it was the most fulfilling experience of my life.",
    avatar: "SR",
    avatarColor: "bg-orange-500",
  },
  {
    id: 3,
    name: "Amir Khan",
    role: "Corporate Partner",
    location: "Delhi",
    rating: 5,
    text: "Our company partnered with Inamigos Foundation for CSR activities. The professionalism, accountability, and genuine impact on ground is impressive. Highly recommend for corporate partnerships.",
    avatar: "AK",
    avatarColor: "bg-blue-500",
  },
  {
    id: 4,
    name: "Deepika Nair",
    role: "Monthly Donor",
    location: "Chennai",
    rating: 5,
    text: "I started with a small monthly donation and seeing the annual reports made me increase my contribution. The breakdown of every rupee spent is something I haven't seen in any other NGO.",
    avatar: "DN",
    avatarColor: "bg-purple-500",
  },
];

function StarRating({ count }: { count: number }) {
  return (
    <div className="flex gap-1">
      {Array.from({ length: count }).map((_, i) => (
        <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
      ))}
    </div>
  );
}

export function Testimonials() {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-80px" });
  const [current, setCurrent] = useState(0);

  const prev = () => setCurrent((c) => (c === 0 ? testimonials.length - 1 : c - 1));
  const next = () => setCurrent((c) => (c === testimonials.length - 1 ? 0 : c + 1));

  return (
    <section className="py-20 bg-gradient-to-br from-green-700 to-green-900" ref={ref}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6 }}
          className="text-center mb-14"
        >
          <span className="text-orange-400 font-semibold uppercase tracking-widest text-sm">Testimonials</span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white mt-2">
            What Our Community Says
          </h2>
        </motion.div>

        {/* Main testimonial */}
        <div className="max-w-3xl mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={current}
              initial={{ opacity: 0, x: 40 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -40 }}
              transition={{ duration: 0.35 }}
              className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-3xl p-8 sm:p-10 text-center"
            >
              <div className="flex justify-center mb-4">
                <div className="w-12 h-12 rounded-full bg-orange-500/20 flex items-center justify-center">
                  <Quote className="w-6 h-6 text-orange-400" />
                </div>
              </div>
              <p className="text-white text-lg sm:text-xl leading-relaxed mb-8 italic">
                "{testimonials[current].text}"
              </p>
              <div className="flex items-center justify-center gap-4">
                <div
                  className={`w-12 h-12 rounded-full ${testimonials[current].avatarColor} flex items-center justify-center text-white font-bold`}
                >
                  {testimonials[current].avatar}
                </div>
                <div className="text-left">
                  <p className="text-white font-bold">{testimonials[current].name}</p>
                  <p className="text-green-300 text-sm">
                    {testimonials[current].role} · {testimonials[current].location}
                  </p>
                </div>
                <div className="ml-2">
                  <StarRating count={testimonials[current].rating} />
                </div>
              </div>
            </motion.div>
          </AnimatePresence>

          {/* Navigation */}
          <div className="flex items-center justify-center gap-4 mt-8">
            <button
              onClick={prev}
              className="w-10 h-10 rounded-full bg-white/15 hover:bg-white/25 flex items-center justify-center text-white transition-colors"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <div className="flex gap-2">
              {testimonials.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setCurrent(i)}
                  className={`h-2 rounded-full transition-all ${i === current ? "bg-orange-400 w-8" : "bg-white/30 w-2"}`}
                />
              ))}
            </div>
            <button
              onClick={next}
              className="w-10 h-10 rounded-full bg-white/15 hover:bg-white/25 flex items-center justify-center text-white transition-colors"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Mini cards grid */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4 mt-12"
        >
          {testimonials.map((t, i) => (
            <button
              key={t.id}
              onClick={() => setCurrent(i)}
              className={`text-left p-4 rounded-2xl border transition-all ${
                i === current
                  ? "bg-white/20 border-white/40"
                  : "bg-white/5 border-white/10 hover:bg-white/10"
              }`}
            >
              <StarRating count={t.rating} />
              <p className="text-white/80 text-xs mt-2 line-clamp-2 italic">"{t.text.slice(0, 70)}..."</p>
              <p className="text-green-300 text-xs font-semibold mt-2">— {t.name}</p>
            </button>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
