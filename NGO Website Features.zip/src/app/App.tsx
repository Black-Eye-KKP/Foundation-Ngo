import { Navbar } from "./components/Navbar";
import { Hero } from "./components/Hero";
import { ImpactDashboard } from "./components/ImpactDashboard";
import { DonationTransparency } from "./components/DonationTransparency";
import { SuccessStories } from "./components/SuccessStories";
import { Testimonials } from "./components/Testimonials";
import { CampaignCards } from "./components/CampaignCards";
import { Footer } from "./components/Footer";

export default function App() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <Hero />
      <ImpactDashboard />
      <DonationTransparency />
      <SuccessStories />
      <Testimonials />
      <CampaignCards />
      <Footer />
    </div>
  );
}
